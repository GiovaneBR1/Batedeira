package com.batedeira.projeto.entity.enums;

/* Objetivo: É o "carimbo" do resultado da validação
  	do (Service). */

public enum statusBatelada {

	OK,
    FORA_DE_TOLERANCIA,
    ERRO
	
}

