package com.batedeira.projeto.entity.enums;

/* Objetivo: Ele é um "carimbo" que garante que o 'modo'
 só pode ser MANUAL ou AUTOMATICO, e nada mais.*/

public enum modoBatedeira {
	
	MANUAL,
    AUTOMATICO
    
}


