package com.batedeira.projeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatedeiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
